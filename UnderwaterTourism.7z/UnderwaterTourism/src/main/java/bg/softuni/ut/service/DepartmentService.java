package bg.softuni.ut.service;

import java.util.List;

import bg.softuni.ut.model.dto.DepartmentDTO;

public interface DepartmentService {

	List<DepartmentDTO> getAllDepartments();

}
