package bg.softuni.ut.model.entity.enums;

public enum PartOfDayEnum {
	Day,Night,Both
}
