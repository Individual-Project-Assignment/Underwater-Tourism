package bg.softuni.ut.model.entity.enums;

public enum UserGenderEnum {
	Male,Female
}
