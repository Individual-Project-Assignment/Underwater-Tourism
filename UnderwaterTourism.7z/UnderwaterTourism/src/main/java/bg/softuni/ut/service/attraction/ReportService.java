package bg.softuni.ut.service.attraction;

import bg.softuni.ut.model.dto.ReportDTO;

public interface ReportService {

	void createReport(ReportDTO reportDTO);

}
