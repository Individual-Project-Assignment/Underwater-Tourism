package bg.softuni.ut.model.entity.enums;

public enum UserRoleEnum {
	ADMIN, 
	USER, 
	EMPLOYEE, 
	MANAGER
}
