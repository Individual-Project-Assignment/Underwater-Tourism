package bg.softuni.ut;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UnderwaterTourismApplicationTests {

	@Test
	void contextLoads() {
	}

}
